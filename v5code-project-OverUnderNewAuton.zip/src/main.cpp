/*----------------------------------------------------------------------------*/
/* */
/* Module: main.cpp */
/* Author: VEX */
/* Created: Thu Sep 11 2001*/
/* Description: Competition Template */
/* */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// rightFront           motor         1               
// rightBack            motor         2               
// rightMid             motor         3               
// leftFront            motor         4               
// leftBack             motor         5               
// leftMid              motor         6               
// Intake               motor         7               
// Slingshot            motor         8               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>
#include <string>

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/* Pre-Autonomous Functions */
/* */
/* You may want to perform some actions before the competition starts. */
/* Do them in the following function. You must return from this function */
/* or the autonomous and usercontrol tasks will not be started. This */
/* function is only called once after the V5 has been powered on and */
/* not every time that the robot is disabled. */
/*---------------------------------------------------------------------------*/

//auton selector 
int autonselect = 1;
int numOfAutons = 2;

int getSign (double inputValue) {
 if (inputValue > 0){
 return 1;
 }
 else if (inputValue < 0){
 return -1;
 }
 else return 0;
}

void driveFunction(){
 
}
//PID settings
double kP = 0.13;
double kI = 0.24;
double kD = 0.5465;
double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;

int error; //SensorValue - DesiredValue --- positional value
int prevError = 0; //position 20 milliseconds ago
int derivative; //difference between error and previous error --- calculates speed
int totalError = 0;// totalError = totalError + error --- integral converts position to absement

//turn variables
int turnError; //SensorValue - DesiredValue --- positional value
int turnPrevError = 0; //position 20 milliseconds ago
int turnDerivative; //difference between error and previous error --- calculates speed
int turnTotalError = 0;

int desiredValue = 0;
int desiredTurnValue = 0;

bool enabledrivePID = true;
//switch to reset the Drive
bool resetDriveSensors = false;


int drivePID(){
 
 while(enabledrivePID){

 if(resetDriveSensors){
 resetDriveSensors = false;

 rightFront.setPosition(0, degrees);
 leftFront.setPosition(0, degrees);
 leftBack.setPosition(0, degrees);
 rightBack.setPosition(0, degrees);
 }
 //get the position of the motors
 int rightFrontPosition = rightFront.position(degrees);
 int leftFrontPosition = leftFront.position(degrees);
 int leftBackPosition = leftBack.position(degrees);
 int rightBackPosition = rightBack.position(degrees);
 //////////////////////////////////////////////////////////////////////////////////
 //lateral movement PID
 ////////////////////////////////////////////////////////////////////////
 //get the average of the four motors
 int averagePosition = (rightFrontPosition + leftFrontPosition + leftBackPosition + rightBackPosition)/4;

 error = averagePosition - desiredValue;

 derivative = error - prevError;

 //absement = position * time -- this is the integral
 totalError += error;

 //add everything up to a mootor power
 double lateralMotorPower = (error * kP + derivative * kD + totalError * kI)/12;

 //////////////////////////////////////////////////////////////////////////////////
 //turning PID
 int turnDifference = (rightFrontPosition - leftFrontPosition);

 turnError = turnDifference - desiredTurnValue;

 turnDerivative = turnError - turnPrevError;

 //absement = position * time -- this is the integral
 turnTotalError += turnError;

 //add everything up to a mootor power
 double turnMotorPower = (turnError * turnkP + turnDerivative * turnkD + turnTotalError * turnkI)/12.0;
 ////////////////////////////////////////////////////////////////////////
 //putting in the motor power into the motor statements
 rightFront.spin(forward, lateralMotorPower + turnMotorPower, percent);
 rightMid.spin(forward, lateralMotorPower + turnMotorPower, percent);
 leftFront.spin(forward, lateralMotorPower - turnMotorPower, percent);
 leftBack.spin(forward, lateralMotorPower - turnMotorPower, percent);
 leftMid.spin(forward, lateralMotorPower - turnMotorPower, percent);
 rightBack.spin(forward, lateralMotorPower + turnMotorPower, percent);
 

 prevError = error;
 turnPrevError = turnError;

 vex::task::sleep(20);
 }

 return 1;

} 


void simpleDrive(){
 int forwardAmount = Controller1.Axis1.position();
 int turnAmount = Controller1.Axis3.position();
 rightFront.setVelocity(60, percent);
 rightMid.setVelocity(60, percent);
 leftFront.setVelocity(60, percent);
 leftMid.setVelocity(60, percent);
 leftBack.setVelocity(60, percent);
 rightBack.setVelocity(60, percent);

 rightFront.spin(reverse,forwardAmount - turnAmount, percent);
 leftFront.spin(forward, forwardAmount + turnAmount, percent);
 leftMid.spin(forward, forwardAmount + turnAmount, percent);
 leftBack.spin(forward, forwardAmount + turnAmount, percent);
 rightMid.spin(reverse,forwardAmount - turnAmount, percent);
 rightBack.spin(reverse,forwardAmount - turnAmount, percent);
}




void intakeCode(){
 Intake.setVelocity(100, percent);
 if(Controller1.ButtonR2.pressing()){
 Intake.spin(forward);
 
 }
 else if(Controller1.ButtonR1.pressing()){
 Intake.spin(reverse);
  
 }
 else{
 Intake.stop();
 
 }
}

void moveForward(int amount){
  rightFront.spinFor(forward,amount,degrees, false);
  rightBack.spinFor(forward,amount,degrees, false);
  rightMid.spinFor(forward,amount,degrees, false);
  leftFront.spinFor(forward,amount,degrees, false);
  leftBack.spinFor(forward,amount,degrees, false);
  leftMid.spinFor(forward,amount,degrees, true);
}


void moveBackward(int amount){
  rightFront.spinFor(reverse,amount,degrees, false);
  rightBack.spinFor(reverse,amount,degrees, false);
  rightMid.spinFor(reverse,amount,degrees, false);
  leftFront.spinFor(reverse,amount,degrees, false);
  leftBack.spinFor(reverse,amount,degrees, false);
  leftMid.spinFor(reverse,amount,degrees, true);
}


void turnLeft(int amount){
  leftFront.spinFor(reverse, amount,degrees,false);
  rightFront.spinFor(forward, amount,degrees);
  
  }

void turnRight(int amount){
  leftFront.spinFor(forward, amount,degrees,false);
  rightFront.spinFor(reverse, amount,degrees);
  
  }

  


void CataCode(){
 Slingshot.setVelocity(100, percent);
 if(Controller1.ButtonL1.pressing()){
 Slingshot.spin(reverse);
 
 }
 else if(Controller1.ButtonL2.pressing()){
 Slingshot.spin(forward);
  
 }
 else{
 Slingshot.setStopping(hold);
 
 }
}


 int selected = 0;
std::string autons[3] = {"Disabled", "AWP Auton", "Scoring Auton"};
int size = sizeof(autons);

bool elevated = false;

void autonSelector(){
 Controller1.Screen.clearScreen();
 task::sleep(100);
 while(true){
 Controller1.Screen.clearScreen();
 task::sleep(100);
 Controller1.Screen.clearLine(2);
 Controller1.Screen.setCursor(2,1);
 Controller1.Screen.setCursor(2,1);
 Controller1.Screen.setCursor(2,1);
 Controller1.Screen.print((autons[selected] + ",").c_str()); //e=mc^2
 Controller1.Screen.newLine();
 Controller1.Screen.print((elevated ? "Elevated" : "Default"));
 task::sleep(100);
 if(Controller1.ButtonRight.pressing()){
 elevated = !elevated;
 if (!elevated) {
 selected = (selected + 1 + size) % size;
 }
 }else if(Controller1.ButtonLeft.pressing()){
 elevated = !elevated;
 if (elevated) {
 selected = (selected - 1 + size) % size;
 }
 }else if(Controller1.ButtonA.pressing()){
 task::sleep(100);
 if(Controller1.ButtonA.pressing()){
 goto slctEnd;
 }
 }
 }
 slctEnd:
 Controller1.rumble("..");
}
void pre_auton(void) {
// Initializing Robot Configuration. DO NOT REMOVE!
 vexcodeInit();
 autonSelector();
 // All activities that occur before the competition starts
 // Example: clearing encoders, setting servo positions, ...
}
/*---------------------------------------------------------------------------*/
/* */
/* Autonomous Task */
/* */
/* This task is used to control your robot during the autonomous phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
 
 switch(selected){
 case 0:{ //Disabled
 break;
 }
 case 1:{ // AWP Auton
 moveForward(100);
 turnRight(50);
 moveForward(50);
 Intake.spinFor(reverse, 50,degrees);
 moveForward(50);
 moveBackward(100);
 turnRight(50);
 moveForward(100);
break;
 }
 case 2:{ // Scoring Auton
  rightBack.spinFor(forward,5000, vex::rotationUnits::deg, false);
  leftBack.spinFor(forward,5000, vex::rotationUnits::deg);

 
 break;
 }
}
/*======================================================================================================================
 example of how to do PID in auton
 resetDriveSensors = true;
 desiredValue = 300; //move forward 300
 desiredTurnValue = 600; //turn 600

 vex::task::sleep(1000); // have it stop for a second

 desiredValue = 300; //move forward 300
 desiredTurnValue = 300; //turn 300
 =======================================================================================================================*/

}

/*---------------------------------------------------------------------------*/
/* */
/* User Control Task */
/* */
/* This task is used to control your robot during the user control phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
 // User control code here, inside the loop
 while (1) {
 simpleDrive();
 intakeCode();
 CataCode();

 //expansion using two pistons being controlled together
 //these pistons will use boolean values to send info to the brain
 //so we will be using simple detection for this
 
 /*===============================================TO BE FINISHED========================================================*/
 //flywheel
 //flywheelCode();
 //catapult
 //catapultCode();
 /*=====================================================================================================================*/

 wait(20, msec); // Sleep the task for a short amount of time to
 // prevent wasted resources.
 }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
 // Set up callbacks for autonomous and driver control periods.
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);

 // Run the pre-autonomous function.
 pre_auton();

 // Prevent main from exiting with an infinite loop.
 while (true) {
 wait(100, msec);
 }
}
