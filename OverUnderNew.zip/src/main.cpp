/*----------------------------------------------------------------------------*/
/* */
/* Module: main.cpp */
/* Author: VEX */
/* Created: Fri Jul 27 2023 */
/* Description: Competition Template */
/* */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name] [Type] [Port(s)]
// Controller1 controller 
// rightFront motor 1
// leftFront motor 4
//leftMid motor 7
//rightMid motor 3
// leftBack motor 5 
// rightBack motor 2 
// Intake motor 6
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>
#include <string>

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/* Pre-Autonomous Functions */
/* */
/* You may want to perform some actions before the competition starts. */
/* Do them in the following function. You must return from this function */
/* or the autonomous and usercontrol tasks will not be started. This */
/* function is only called once after the V5 has been powered on and */
/* not every time that the robot is disabled. */
/*---------------------------------------------------------------------------*/



void simpleDrive(){
 int forwardAmount = Controller1.Axis3.position();
 int turnAmount = Controller1.Axis1.position();
 rightFront.setVelocity(100, percent);
 leftFront.setVelocity(100, percent);
 leftBack.setVelocity(100, percent);
 rightBack.setVelocity(100, percent);

 rightFront.spin(reverse,forwardAmount - turnAmount, percent);
 leftFront.spin(forward, forwardAmount + turnAmount, percent);
 leftBack.spin(reverse, forwardAmount + turnAmount, percent);
 rightBack.spin(forward, forwardAmount - turnAmount, percent);
}




void intakeCode(){
 if(Controller1.ButtonL1.pressing()){
 Intake.spin(forward);
 
 }
 else if(Controller1.ButtonL2.pressing()){
 Intake.spin(reverse);
 
 }
 else{
 Intake.stop();
 
 }
}


bool elevated = false;

void autonSelector(){
}
void pre_auton(void) {
// Initializing Robot Configuration. DO NOT REMOVE!
 vexcodeInit();
 autonSelector();
 // All activities that occur before the competition starts
 // Example: clearing encoders, setting servo positions, ...
}
/*---------------------------------------------------------------------------*/
/* */
/* Autonomous Task */
/* */
/* This task is used to control your robot during the autonomous phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
 
 
}

/*---------------------------------------------------------------------------*/
/* */
/* User Control Task */
/* */
/* This task is used to control your robot during the user control phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
 // User control code here, inside the loop
 while (true) {
 simpleDrive();
 intakeCode();
 

 wait(20, msec); // Sleep the task for a short amount of time to
 // prevent wasted resources.
 }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
 // Set up callbacks for autonomous and driver control periods.
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);

 // Run the pre-autonomous function.
 pre_auton();

 // Prevent main from exiting with an infinite loop.
 while (true) {
 wait(100, msec);
 }
}