/*----------------------------------------------------------------------------*/
/* */
/* Module: main.cpp */
/* Author: VEX */
/* Created: Thu Sep 26 2019 */
/* Description: Competition Template */
/* */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name] [Type] [Port(s)]
// rightFront motor 1 
// rightBack motor 2 
// rightMid motor 3 
// leftFront motor 4 
// leftBack motor 5 
// leftMid motor 6 
// Intake motor 7 
// Slingshot motor 8 
// Controller1 controller 
// Blocks digital_out A 
// Flaps digital_out B 
// Inertial inertial 9 
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>
#include <string>

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/* Pre-Autonomous Functions */
/* */
/* You may want to perform some actions before the competition starts. */
/* Do them in the following function. You must return from this function */
/* or the autonomous and usercontrol tasks will not be started. This */
/* function is only called once after the V5 has been powered on and */
/* not every time that the robot is disabled. */
/*---------------------------------------------------------------------------*/

//auton selector 
int autonselect = 1;
int numOfAutons = 2;

int getSign (double inputValue) {
 if (inputValue > 0){
 return 1;
 }
 else if (inputValue < 0){
 return -1;
 }
 else return 0;
}

void driveFunction(){
 
}




// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!
// Needed Code!!!

void simpleDrive(){
 int forwardAmount = Controller1.Axis1.position();
 int turnAmount = (Controller1.Axis3.position()* 0.50);
 rightFront.setVelocity(100, percent);
 rightMid.setVelocity(100, percent);
 leftFront.setVelocity(100, percent);
 leftMid.setVelocity(100, percent);
 leftBack.setVelocity(100, percent);
 rightBack.setVelocity(100, percent);

 rightFront.spin(reverse,forwardAmount - turnAmount, percent);
 leftFront.spin(forward, forwardAmount + turnAmount, percent);
 leftMid.spin(forward, forwardAmount + turnAmount, percent);
 leftBack.spin(forward, forwardAmount + turnAmount, percent);
 rightMid.spin(reverse,forwardAmount - turnAmount, percent);
 rightBack.spin(reverse,forwardAmount - turnAmount, percent);
}

void Velocity(bool amount){
 rightFront.setVelocity(amount, percent);
 rightMid.setVelocity(amount, percent);
 leftFront.setVelocity(amount, percent);
 leftMid.setVelocity(amount, percent);
 leftBack.setVelocity(amount, percent);
 rightBack.setVelocity(amount, percent);
}


void Forward(bool forward_amount){
 rightFront.setVelocity(75, percent);
 rightMid.setVelocity(75, percent);
 leftFront.setVelocity(75, percent);
 leftMid.setVelocity(75, percent);
 leftBack.setVelocity(75, percent);
 rightBack.setVelocity(75, percent);
 ////
 rightFront.spinFor(forward,forward_amount, degrees, false);
 rightMid.spinFor(forward,forward_amount, degrees, false);
 rightBack.spinFor(forward,forward_amount, degrees, false);
 leftMid.spinFor(forward,forward_amount, degrees, false);
 leftFront.spinFor(forward,forward_amount, degrees, false);
 leftBack.spinFor(forward,forward_amount, degrees, true);
}


void Reverse(bool reverse_amount){
 rightFront.setVelocity(75, percent);
 rightMid.setVelocity(75, percent);
 leftFront.setVelocity(75, percent);
 leftMid.setVelocity(75, percent);
 leftBack.setVelocity(75, percent);
 rightBack.setVelocity(75, percent);
 ////
 rightFront.spinFor(reverse,reverse_amount, degrees, false);
 rightMid.spinFor(reverse,reverse_amount, degrees, false);
 rightBack.spinFor(reverse,reverse_amount, degrees, false);
 leftMid.spinFor(reverse,reverse_amount, degrees, false);
 leftFront.spinFor(reverse,reverse_amount, degrees, false);
 leftBack.spinFor(reverse,reverse_amount, degrees, true);
}

void TurnClockwise(double target){
 Inertial.setRotation(0,degrees);
 rightFront.setVelocity(20, percent);
 rightMid.setVelocity(20, percent);
 leftFront.setVelocity(20, percent);
 leftMid.setVelocity(20, percent);
 leftBack.setVelocity(20, percent);
 rightBack.setVelocity(20, percent);
 while (true) {
 if(Inertial.rotation(degrees) < target){
 leftFront.spin(forward);
 leftMid.spin(forward);
 leftBack.spin(forward);
 rightFront.spin(reverse);
 rightMid.spin(reverse);
 rightBack.spin(reverse);
 }
 else if (Inertial.rotation(degrees) > target){
 leftFront.stop();
 leftMid.stop();
 leftBack.stop();
 rightFront.stop();
 rightMid.stop();
 rightBack.stop(); 
 return;
 }
 }
 }





 void TurnToDirection(double howmuch){
 rightFront.setVelocity(20, percent);
 rightMid.setVelocity(20, percent);
 leftFront.setVelocity(20, percent);
 leftMid.setVelocity(20, percent);
 leftBack.setVelocity(20, percent);
 rightBack.setVelocity(20, percent);
 while (true) {
 if(Inertial.heading(degrees) != (howmuch-3) or (howmuch+3) or (howmuch+2) or (howmuch+1) or (howmuch-2) or (howmuch-1)){
 leftFront.spin(forward);
 leftMid.spin(forward);
 leftBack.spin(forward);
 rightFront.spin(reverse);
 rightMid.spin(reverse);
 rightBack.spin(reverse);
 }
 else if (Inertial.rotation(degrees) > howmuch){
 leftFront.stop();
 leftMid.stop();
 leftBack.stop();
 rightFront.stop();
 rightMid.stop();
 rightBack.stop(); 
  rightFront.setVelocity(100, percent);
 rightMid.setVelocity(100, percent);
 leftFront.setVelocity(100, percent);
 leftMid.setVelocity(100, percent);
 leftBack.setVelocity(100, percent);
 rightBack.setVelocity(100, percent);
 return;
 }
 }
 }



///////////////


///////////////////

//////////////////
double kpamount = 0.07;
double kiamount = 0;
double kdamount = 0;

// Drivetrain PID Function
void drivePID(double targetdegrees, double kp, double ki, double kd) {
 double error = targetdegrees;
 double integral = 0;
 double lasterror = error;
 double speed;
 double prevdegrees = leftFront.position(degrees);

 double count = 0;

 leftFront.setPosition(0, degrees);
 leftBack.setPosition(0, degrees);
 rightFront.setPosition(0, degrees);
 rightBack.setPosition(0, degrees);
 leftMid.setPosition(0, degrees);
 rightMid.setPosition(0, degrees);
 while (true) {
   double measureddegrees = (leftFront.position(degrees) + rightFront.position(degrees)) / 2;
   error = targetdegrees - measureddegrees;

   if (fabs(measureddegrees - prevdegrees) < 3) {
     count++; // add to count
   } else {   // if not being stalled
     count = 0;
   }

   if (count > 10) { // exit when stuck for 200 ms
     leftFront.stop();
     leftBack.stop();
     rightFront.stop();
     rightBack.stop();
     leftMid.stop();
     rightMid.stop();
     Controller1.Screen.clearScreen();
     Controller1.Screen.setCursor(1, 1);
     Controller1.Screen.print("stalled");
     wait(3000,msec);
     return;
   }

   // Controller1.Screen.clearScreen();
   // Controller1.Screen.setCursor(1, 1);
   // Controller1.Screen.print(measureddegrees);
   prevdegrees = measureddegrees;

   // Integral windup
   if (fabs(error) < targetdegrees/10*3 && fabs(integral) < 300) {//fabs(error) < 300
     integral += error;
   }
   if (fabs(error) < 30 /* || fl.current(amp) > 3.0*/) { // exit condition
     leftFront.stop();
     leftBack.stop();
     rightFront.stop();
     rightBack.stop();
     leftMid.stop();
     rightMid.stop();

     Controller1.Screen.clearScreen();
     Controller1.Screen.setCursor(1, 1);
     Controller1.Screen.print(error);
     wait(3000,msec);
     return;
   }

   speed = error * kp + integral * ki + (error - lasterror) * kd; // motor speed

   leftFront.spin(forward, speed, rpm);
   leftBack.spin(forward, speed, rpm);
   rightFront.spin(forward, speed, rpm);
   rightBack.spin(forward, speed, rpm);
   leftMid.spin(forward, speed, rpm);
   rightMid.spin(forward, speed, rpm);
   lasterror = error;
   wait(20, msec);
 }
}

void TurnAntiClockwise(double target){
 Inertial.resetRotation();
 rightFront.setVelocity(20, percent);
 rightMid.setVelocity(20, percent);
 leftFront.setVelocity(20, percent);
 leftMid.setVelocity(20, percent);
 leftBack.setVelocity(20, percent);
 rightBack.setVelocity(20, percent);
 while (true) {
 if(Inertial.rotation(degrees) > -target){
 leftFront.spin(reverse);
 leftMid.spin(reverse);
 leftBack.spin(reverse);
 rightFront.spin(forward);
 rightMid.spin(forward);
 rightBack.spin(forward);
 }
 else if (Inertial.rotation(degrees) > target){
 leftFront.stop();
 leftMid.stop();
 leftBack.stop();
 rightFront.stop();
 rightMid.stop();
 rightBack.stop(); 
 return;
 }
 }
 }


void intakeCode(){
 Intake.setVelocity(100, percent);
 if(Controller1.ButtonR1.pressing()){
 Intake.spin(forward);
 
 }
 else if(Controller1.ButtonR2.pressing()){
 Intake.spin(reverse);
 
 }
 else{
 Intake.stop();
 
 }
}


















void BlocksCode(){
 if(Controller1.ButtonX.pressing()){
 Blocks.set(true);
 }
 else if(Controller1.ButtonB.pressing()){
 Blocks.set(false);
 }
}

void FlapsCode(){
 if(Controller1.ButtonUp.pressing()){
 Flaps.set(true);
 }
 else if(Controller1.ButtonDown.pressing()){
 Flaps.set(false);
 }
}


void CataDownCode(){
 if(Controller1.ButtonY.pressing()){
Slingshot.spinFor(forward,100,degrees);
 }
}



void CataCode(){
 Slingshot.setVelocity(70, percent);
 if(Controller1.ButtonL2.pressing()){
 Slingshot.spin(forward);
 
 }
 else if(Controller1.ButtonL1.pressing()){
 Slingshot.spin(reverse);
 
 }
 else{
 Slingshot.stop();
 
 }
}


 int selected = 0;
std::string autons[5] = {"Disabled", "Quals AWP", "SCORING", "SKILLS", "ELIMS AWP"};
int size = sizeof(autons);

bool elevated = false;

void autonSelector(){
 Controller1.Screen.clearScreen();
 task::sleep(100);
 while(true){
 Controller1.Screen.clearScreen();
 task::sleep(100);
 Controller1.Screen.clearLine(2);
 Controller1.Screen.setCursor(2,1);
 Controller1.Screen.print((autons[selected] + ",").c_str()); //e=mc^2
 Controller1.Screen.newLine();
 Controller1.Screen.print((elevated ? "Elevated" : "Default"));
 task::sleep(100);
 if(Controller1.ButtonRight.pressing()){
 elevated = !elevated;
 if (!elevated) {
 selected = (selected + 1 + size) % size;
 }
 }else if(Controller1.ButtonLeft.pressing()){
 elevated = !elevated;
 if (elevated) {
 selected = (selected - 1 + size) % size;
 }
 }else if(Controller1.ButtonA.pressing()){
 task::sleep(100);
 if(Controller1.ButtonA.pressing()){
 goto slctEnd;
 }
 }
 }
 slctEnd:
 Controller1.rumble("..");
  Inertial.calibrate();
  Inertial.setHeading(0,degrees);
}
void pre_auton(void) {
// Initializing Robot Configuration. DO NOT REMOVE!
 vexcodeInit();
 autonSelector();
 // All activities that occur before the competition starts
 // Example: clearing encoders, setting servo positions, ...
}
/*---------------------------------------------------------------------------*/
/* */
/* Autonomous Task */
/* */
/* This task is used to control your robot during the autonomous phase of */
/* a VEX Competition. */
/* */

/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
 switch(selected){
 
case 0:{ //Disabled
 break;


 case 1:{ ///Quals AWP
  
Inertial.calibrate();
while (Inertial.isCalibrating()){
 wait(100,msec);  
}
drivePID(100, kpamount, kiamount, kdamount);


TurnClockwise(80);

 break;
 }
 case 2:{ // SCORING
 



while (Inertial.isCalibrating()){
 wait(100,msec);
}
 




 break;
 }
 case 3:{ ///SKILLS

while (Inertial.isCalibrating()){
 wait(100,msec);
}



break;
 }



 case 4:{ ////Elims AWP

while (Inertial.isCalibrating()){
 wait(100,msec);
}


 }
}
/*======================================================================================================================
 example of how to do PID in auton
 resetDriveSensors = true;
 desiredValue = 300; //move forward 300
 desiredTurnValue = 600; //turn 600

 vex::task::sleep(1000); // have it stop for a second

 desiredValue = 300; //move forward 300
 desiredTurnValue = 300; //turn 300
 =======================================================================================================================*/

}

/*---------------------------------------------------------------------------*/
/* */
/* User Control Task */
/* */
/* This task is used to control your robot during the user control phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/

}
void usercontrol(void) {
 // User control code here, inside the loop
 while (1) {
 simpleDrive();
 intakeCode();
 CataCode();
 FlapsCode();
 BlocksCode();
 CataDownCode();
 //expansion using two pistons being controlled together
 //these pistons will use boolean values to send info to the brain
 //so we will be using simple detection for this
 
 /*===============================================TO BE FINISHED========================================================*/
 //flywheel
 //flywheelCode();
 //catapult
 //catapultCode();
 /*=====================================================================================================================*/

 wait(20, msec); // Sleep the task for a short amount of time to
 // prevent wasted resources.
 }
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
 // Set up callbacks for autonomous and driver control periods.
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);

 // Run the pre-autonomous function.
 pre_auton();

 // Prevent main from exiting with an infinite loop.
 while (true) {
 wait(100, msec);
 }
}